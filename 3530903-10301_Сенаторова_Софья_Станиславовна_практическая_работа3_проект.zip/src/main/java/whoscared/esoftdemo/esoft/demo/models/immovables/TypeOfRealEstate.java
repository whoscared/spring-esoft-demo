package whoscared.esoftdemo.esoft.demo.models.immovables;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

public enum TypeOfRealEstate {
    APARTMENT,
    HOUSE,
    LAND


}
