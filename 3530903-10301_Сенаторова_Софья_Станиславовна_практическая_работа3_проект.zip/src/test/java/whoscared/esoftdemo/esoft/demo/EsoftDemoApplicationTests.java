package whoscared.esoftdemo.esoft.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsoftDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
